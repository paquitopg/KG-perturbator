# KG-perturbator

A Python package for applying controlled perturbations to Knowledge Graphs (KGs) in JSON format. Useful for generating test/finetuning sets for entity alignment, robustness evaluation, and adversarial testing.

## Features
- Add/remove entities (nodes)
- Add/remove relations (edges)
- Rename entities (LLM-based, synonyms, abbreviations, etc.)
- Attribute and schema perturbations (optional)
- Configurable perturbation degree and random seed
- Maintains mapping between original and perturbed KGs for ground truth alignment
- **Hybrid approach:** Accepts JSON-format KGs, uses NetworkX internally for graph operations

## Installation

```bash
pip install .
```

## Basic Usage

```python
from kg_perturbator import KGPerturbator
import json

with open("sampleKG.json") as f:
    kg_json = json.load(f)

perturbator = KGPerturbator(config={
    "remove_entities": 5,
    "add_entities": 2,
    "remove_edges": 10,
    # "rename_entities": lambda name: name.upper(),
})
perturbed_kg, mapping = perturbator.perturb(kg_json)

with open("perturbedKG.json", "w") as f:
    json.dump(perturbed_kg, f, indent=2)
```

## Command-Line Interface (CLI)

The package includes a command-line interface for easy use in data processing pipelines.

1.  **Configure Environment Variables**

    Create a `.env` file in the root of the project to store your LLM provider credentials and configuration. You can use `.env.example` as a template. This ensures your sensitive keys and environment-specific settings are kept separate from the main configuration.

    ```bash
    # .env
    LLM_PROVIDER="vertexai"
    VERTEX_MODEL_NAME="gemini-1.0-pro-preview"
    GOOGLE_CLOUD_PROJECT="your-gcp-project-id"
    ```

2.  **Create a Perturbation Configuration File**

    Create a `config.yaml` file to define which perturbations to apply. The LLM details are now handled by the environment variables.

    ```yaml
    # config.yaml
    seed: 42
    remove_entities: 5
    add_edges: 10
    
    llm_perturb_entities:
      update_name: true
      update_description: true
    ```

3.  **Run the CLI**

    Use the `kg-perturb` command, which is installed with the package.

    ```bash
    # Install dependencies
    poetry install

    # Run the perturbation
    poetry run kg-perturb config.yaml path/to/input.json path/to/output.json --mapping path/to/mapping.json
    ```

    **Arguments:**
    - `config.yaml`: Your perturbation configuration file.
    - `input.json`: The source Knowledge Graph.
    - `output.json`: Where to save the perturbed Knowledge Graph.
    - `--mapping` (Optional): Where to save the mapping of renamed entities.

## License
MIT 